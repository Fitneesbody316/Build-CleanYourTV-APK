CleanYourTV - Hyundai Android 7.1.1 cloud build package

This package includes the Android project at repository root and a GitHub Actions workflow.
It does NOT compile inside ChatGPT. GitHub Actions runs Gradle and the Android SDK in the cloud.

Build:
1. Create a GitHub repository and upload/extract the contents of this ZIP into its root.
2. Open the repository's Actions tab.
3. Select "Build CleanYourTV APK" and click "Run workflow" (or push to main/master).
4. When the workflow finishes, open the run and download the artifact named
   CleanYourTV-Hyundai-Android7-APK. Inside is app-debug.apk.

The workflow builds a DEBUG APK (no R8/minification) with applicationId
com.cleanyourtv.hyundai, minSdk 25, targetSdk 25. It has not yet been tested on the target TV.
Keep the stock launcher com.toptech.launcher enabled until the new APK is verified.
